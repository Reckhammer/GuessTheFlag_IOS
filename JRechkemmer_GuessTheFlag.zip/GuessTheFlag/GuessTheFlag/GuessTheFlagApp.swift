//
//  GuessTheFlagApp.swift
//  GuessTheFlag
//
//  Created by Joshua Rechkemmer on 2/29/24.
//

import SwiftUI

@main
struct GuessTheFlagApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
